    const baseurl = 'https://api.gharzoreality.com/';

export default baseurl;
