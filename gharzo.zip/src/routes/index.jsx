export { publicRoutes } from "./publicRoutes";
export { userRoutes } from "./userRoutes";
export { landlordRoutes } from "./landlordRoutes";
export { tenantRoutes } from "./tenantRoutes";
export { subOwnerRoutes } from "./subOwnerRoutes";
export { workerRoutes } from "./workerRoutes";