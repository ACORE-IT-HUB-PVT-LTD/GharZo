import React from "react";
import BookingTabs from "../BookingTabs";

export default function BookingsPage() {
  return <BookingTabs />;
}
