import { div } from 'framer-motion/client'
import React from 'react'

function PropertyFilter() {
  return (
    <div>
        <div>Property Filters</div>

        <div>Use Location</div>
        <select name="" id="">
            <option value="">Indore</option>
        </select>

    </div>
  )
}

export default PropertyFilter