import React from "react";

function Collections() {
  return <div>Collections</div>;
}

export default Collections;
