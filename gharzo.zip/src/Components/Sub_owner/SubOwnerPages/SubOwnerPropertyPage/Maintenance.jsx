import React from "react";

function Maintenance() {
  return <div>Maintenance</div>;
}

export default Maintenance;
